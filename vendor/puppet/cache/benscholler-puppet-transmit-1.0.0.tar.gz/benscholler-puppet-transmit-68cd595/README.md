# Transmit Puppet Module for Boxen

## Usage

```puppet
include transmit
```

## Required Puppet Modules

* boxen
