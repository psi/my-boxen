# Chef Puppet Module for Boxen

Installs Chef via Omnibus package.

## Usage

```puppet
include chef
```

## Required Puppet Modules

* boxen
* stdlib
