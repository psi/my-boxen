# Vagrant Puppet Module for Boxen

## Usage

```puppet
include vagrant
```

## Required Puppet Modules

* boxen
* stdlib
