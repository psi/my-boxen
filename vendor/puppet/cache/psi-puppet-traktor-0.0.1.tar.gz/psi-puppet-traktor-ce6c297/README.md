# Traktor Puppet Module for Boxen

## Usage

```puppet
include traktor
```

## Required Puppet Modules

* boxen
* stdlib
