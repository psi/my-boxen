# Quicksilver Puppet Module for Boxen

## Usage

```puppet
include quicksilver
```

## Required Puppet Modules

* boxen
* stdlib
