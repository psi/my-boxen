# StreetEasy Puppet Module for Boxen

## Usage

```puppet
include streeteasy
```

## Required Puppet Modules

* boxen
* stdlib
